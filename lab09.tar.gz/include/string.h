int strcmp(char * str1,char* str2);
